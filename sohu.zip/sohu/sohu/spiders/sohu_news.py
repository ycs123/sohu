# -*- coding: utf-8 -*-

import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from ..items import SohuItem


class SohuNewsSpider(CrawlSpider):
    name = 'sohu_news'
    # allowed_domains = ['ddd']
    start_urls = ['http://news.sohu.com/']

    rules = (
        Rule(LinkExtractor(allow='www.sohu.com/a/\d+_\d+', restrict_xpaths='//li/a'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        item = SohuItem()
        try:
            if response.xpath('string(//h1)').extract_first()[0]:
                title = response.xpath('string(//h1)').extract_first().replace(' ', '').replace('\n', '')
                time_data = response.xpath('//div[@class="article-info"]/span/text()').extract_first()
                source = response.xpath('//div[@class="article-info"]/span/a/text()').extract_first()
                url = response.url
                item['title'] = title
                item['time_data'] = time_data
                item['source'] = source
                item['url'] = url
                yield item

        except:
            title = response.xpath('string(//h3)').extract()[0].replace(' ', '').replace('\n', '')
            time_data = response.xpath('//div[@class="article-info"]/span/text()').extract_first()
            source = response.xpath('//div[@class="article-info"]/span/a/text()').extract_first()
            url = response.url
            item['title'] = title
            item['time_data'] = time_data
            item['source'] = source
            item['url'] = url
            yield item

        try:
            mpId = re.findall('http://www.sohu.com/a/(.*?)_.*', response.url)[0]
            if response.xpath('//body/@data-region').extract_first()[0]:
                data = response.xpath('//body/@data-region').extract_first()
                yield scrapy.Request('http://v2.sohu.com/integration-api/mix/region/{}?size=100&mpId={}'
                                     .format(data, mpId), callback=self.parse_detail)
        except:
            for page in range(1,51):
                yield scrapy.Request('http://v2.sohu.com/public-api/feed?scene=CHANNEL&sceneId=18&page={}&size=20'
                                     .format(page), callback=self.parse_detail)

    def parse_detail(self, response):
        base_url = 'http://www.sohu.com'
        detail_urls = re.findall('"url":"(.*?)"', response.text)
        if detail_urls != []:
            for detail_url in detail_urls:
                yield scrapy.Request(base_url+detail_url, callback=self.parse_item)
        else:
            detail_urls = re.findall('"id":(\d+),"authorId":(\d+)', response.text)
            for detail_url in detail_urls:
                yield scrapy.Request(base_url+'/a/'+detail_url[0]+'_'+detail_url[1], callback=self.parse_item)



# http://v2.sohu.com/integration-api/mix/region/154?size=100&mpId=330909746
# http://v2.sohu.com/integration-api/mix/region/144?size=100&mpId=330895002

# http://v2.sohu.com/public-api/feed?&scene=CHANNEL&sceneId=18&page=1&size=20
# http://v2.sohu.com/public-api/feed?scene=CHANNEL&sceneId=18&page=13&size=20
# http://v2.sohu.com/public-api/feed?scene=CHANNEL&sceneId=18&page=50&size=20
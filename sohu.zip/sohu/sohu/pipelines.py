# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import pymongo
from openpyxl import Workbook


class SohuPipeline(object):
    def process_item(self, item, spider):
        with open('sohu.text', 'a', encoding='utf-8') as f:
            f.write(str(item) + '\n')
        return item


class SohuPipeline_xlsx:
    wb = Workbook()
    ws = wb.active
    ws.append(['title', 'time_data', 'source', 'url'])

    def process_item(self, item, spider):
        self.ws.append([item['title'], item['time_data'], item['source'], item['url']])
        self.wb.save('sohu.xlsx')
        return item


class SohuPiprline_mongo:
    def __init__(self):
        self.connection = pymongo.MongoClient(host='127.0.0.1', port=27017)
        db = self.connection['sohu']
        self.col = db['info']

    def process_item(self, item, spider):
        self.col.save(dict(item))
        return item

    def close(self):
        self.connection.close()
